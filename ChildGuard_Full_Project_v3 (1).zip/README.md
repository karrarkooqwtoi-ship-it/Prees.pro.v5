# ChildGuard Parental Control App

Modern RTL Jetpack Compose (Kotlin) Parental Control Solution with Node.js Backend and Codemagic CI/CD Build Setup.

## Features
- Parent & Child Modes
- Modern Orange-themed Material 3 UI (RTL Support)
- 6-digit Device Pairing Code
- Real-time Battery & Connectivity Status
- GPS Location & Geofencing
- Screen Time & App Usage Statistics
- Emergency SOS Button
- Codemagic ready (`codemagic.yaml`)

## Project Structure
- `codemagic.yaml`: Auto-build configuration for Codemagic APK generation
- `childguard-android/`: Jetpack Compose Android App
- `childguard-backend/`: Node.js Express REST API & WebSocket Server
