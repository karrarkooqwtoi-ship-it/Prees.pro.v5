
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.json());

app.get('/api/status', (req, res) => {
    res.json({ status: "ChildGuard Backend Running", time: new Date() });
});

io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    socket.on('pair_device', (data) => {
        socket.emit('pairing_result', { success: true, message: "تم الاقتران بنجاح" });
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
