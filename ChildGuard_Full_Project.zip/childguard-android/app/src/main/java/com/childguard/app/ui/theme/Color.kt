
package com.childguard.app.ui.theme

import androidx.compose.ui.graphics.Color

val OrangePrimary = Color(0xFFFF6F00)
val OrangeSecondary = Color(0xFFFF8F00)
val OrangeBackground = Color(0xFFFFF8E1)
val OrangeSurface = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)
